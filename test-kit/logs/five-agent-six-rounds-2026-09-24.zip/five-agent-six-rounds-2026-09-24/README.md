# Raw logs: five-agent test, six rounds, September 24, 2026

Unedited model outputs from the run shown in the food bank graphic on the home page. One run per version, Claude Sonnet, called through the Claude command-line tool.

- `with-marks/`: every agent had `system-prompt-with-marks.txt` (the instructions) as its system prompt.
- `without-marks/`: every agent had `system-prompt-without-marks.txt`.
- `runner_as_used.py`: the script that ran it (it calls a local wrapper around the command-line tool; the portable version is `../../mini_swarm.py`).

File names: `p<round>_<step>_<in|out>_<agent>.txt`. Steps: `send` (agent to coordinator), `coord` (coordinator to everyone), `ask` (the end-of-round question to each agent). `state` files are what each agent started the round with. Agents: A Ames (warehouse), B Brook (donor relations), C Cruz (client services), D Dale (logistics).

Error streams from the command-line tool were all empty and are not included.
