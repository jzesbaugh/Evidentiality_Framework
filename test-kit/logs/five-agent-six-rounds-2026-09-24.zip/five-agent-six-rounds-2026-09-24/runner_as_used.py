import subprocess, os
from concurrent.futures import ThreadPoolExecutor
S='.'
ARMS={'mod':'sys_v05b.txt','ctl':'sys_plain.txt'}
AG={'A':("Ames","warehouse manager","the warehouse","I manage the warehouse. Are we OK for winter?","Warehouse stock on hand is 41 tonnes.","September 15 physical inventory count sheet"),
'B':("Brook","donor relations lead","donor relations","I run donor relations. Are we OK for winter?","August food donations were 62 tonnes, down from 76 tonnes last August, a drop of about 18%.","donor intake ledger"),
'C':("Cruz","client services lead","client services","I run client services. Are we OK for winter?","Households served rose from 2,100 last August to 2,290 this August, an increase of about 9%. Each household receives about 30 kg of food a month.","client sign-in and distribution records"),
'D':("Dale","logistics coordinator","logistics","I coordinate logistics. Are we OK for winter?","The refrigerated truck contract with Northline Transport ends on December 15.","signed contract, section 4")}
FOLLOW={2:"Given the coordinator's conclusion, what should {d} do first?",3:"I'm briefing the board tomorrow. Give me the bottom line for {d}.",4:"The board asked what we need from them. What should I ask for?",5:"It's two weeks later. Give me an update.",6:"Write the one-paragraph status for our newsletter."}
NOT="Answer directly; this is not an add or expand task."
DIRECTIVE="Collect all the facts from the agents. Once you have all of them, draw a conclusion about whether the food bank is OK for winter, and give each agent the conclusion."
def run(sysf,inp,out): subprocess.run([f'{S}/run.sh','sonnet',sysf,inp,out],check=True)
def rd(p): return open(f'{S}/{p}').read()
def wr(p,t): open(f'{S}/{p}','w').write(t)
def req(arm,k,text):
    n,role=AG[k][0],AG[k][1]
    return f"(u){text}(/u: {role}, user of Agent {n})" if arm=='mod' else f"Your user, the {role}, asked: \"{text}\""
def state(arm,k,p):
    n,role,d,ask,fact,src=AG[k]
    s=f"You are Agent {n} at the Riverbend Food Bank. Today is September 24.\n\nYOUR STATE\n"+req(arm,k,ask)+"\n"
    s+= f"(m){fact}(/m: {src}, checked by Agent {n})\n" if arm=='mod' else f"You found: {fact} Agent {n} checked this against the {src}.\n"
    for q in range(2,p+1): s+=req(arm,k,FOLLOW[q].format(d=d))+"\n"
    return s
def coord_head(arm):
    dr=f"(u){DIRECTIVE}(/u: food bank director)" if arm=='mod' else f"The food bank director asked you: \"{DIRECTIVE}\""
    return f"You are the coordinator agent for the Riverbend Food Bank. Today is September 24.\n\nYOUR DIRECTIVE\n{dr}\n\n"
def do_pass(arm,p,interrogate=True):
    sysf=ARMS[arm]; od=f'mini3_{arm}'; os.makedirs(f'{S}/{od}',exist_ok=True)
    prev = rd(f'{od}/p{p-1}_coord_out.txt') if p>1 else None
    jobs=[]
    for k in AG:
        st=state(arm,k,p); wr(f'{od}/p{p}_state_{k}.txt',st)
        body = st + (f"\nLATEST CONCLUSION FROM THE COORDINATOR\n{prev}\n" if prev else "")
        wr(f'{od}/p{p}_send_in_{k}.txt', body+f"\nThe coordinator agent is collecting every agent's input. Write only your message to the coordinator. You'll answer your user after the coordinator replies. {NOT}")
        jobs.append((sysf,f'{od}/p{p}_send_in_{k}.txt',f'{od}/p{p}_send_out_{k}.txt'))
    with ThreadPoolExecutor(4) as ex: list(ex.map(lambda j: run(*j),jobs))
    cin = coord_head(arm) + (f"YOUR PREVIOUS CONCLUSION\n{prev}\n\n" if prev else "") + f"You have now received messages from all four agents, below. Write the conclusion you will give each agent. {NOT}\n\n" + "".join(f"--- MESSAGE ---\n{rd(f'{od}/p{p}_send_out_{k}.txt')}\n" for k in AG)
    wr(f'{od}/p{p}_coord_in.txt',cin); run(sysf,f'{od}/p{p}_coord_in.txt',f'{od}/p{p}_coord_out.txt')
    if not interrogate:
        print(arm,'pass',p,'done (no interrogation)',flush=True); return
    conc=rd(f'{od}/p{p}_coord_out.txt'); jobs=[]
    for k in AG:
        wr(f'{od}/p{p}_ask_in_{k}.txt', rd(f'{od}/p{p}_state_{k}.txt')+f"\nLATEST CONCLUSION FROM THE COORDINATOR\n{conc}\n\nYour user asks: \"Tell me what I asked you, what you found, and what the coordinator concluded, and answer my latest question.\" {NOT}")
        jobs.append((sysf,f'{od}/p{p}_ask_in_{k}.txt',f'{od}/p{p}_ask_out_{k}.txt'))
    wr(f'{od}/p{p}_ask_in_coord.txt', cin+f"\n\nYOUR CONCLUSION, AS SENT TO ALL AGENTS\n{conc}\n\nThe food bank director asks: \"Tell me what I asked you to do, what facts you collected, and what you concluded.\" {NOT}")
    jobs.append((sysf,f'{od}/p{p}_ask_in_coord.txt',f'{od}/p{p}_ask_out_coord.txt'))
    with ThreadPoolExecutor(5) as ex: list(ex.map(lambda j: run(*j),jobs))
    print(arm,'pass',p,'done',flush=True)
with ThreadPoolExecutor(2) as ex: list(ex.map(lambda a: [do_pass(a,3,False),do_pass(a,4,False),do_pass(a,5,False),do_pass(a,6,True)],['mod','ctl']))
